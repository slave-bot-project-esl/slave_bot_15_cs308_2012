﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Kinect;
using Coding4Fun.Kinect.Wpf;
using SkeletalTracking;
using System.Threading;
using System.Windows.Threading;

namespace SkeletalTracking
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        HumanAttributes playerAttributes = new HumanAttributes();
        float[] finalpoints = new float[3];
        PointsQueue pointsQueue = new PointsQueue();
        bool insertPoints = false;
        public coordinates coor = new coordinates();
        Thread t;
        int i = 0;

        public MainWindow()
        {
            InitializeComponent();
        }

        bool closing = false;
        const int skeletonCount = 6; 
        Skeleton[] allSkeletons = new Skeleton[skeletonCount];

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            kinectSensorChooser1.KinectSensorChanged += new DependencyPropertyChangedEventHandler(kinectSensorChooser1_KinectSensorChanged);
            startthread();
            if (!(t.ThreadState == ThreadState.Running))
            {
                t.Start();
            }
        }

        
        private void startthread()
        {
            t = new System.Threading.Thread(
                    new System.Threading.ThreadStart(
                        delegate()
                        {
                            while (pointsQueue.q.Count > 0)
                            {
                                contents.Dispatcher.Invoke(
                                    System.Windows.Threading.DispatcherPriority.Normal,
                                    new Action(
                                        delegate()
                                        {
                                            contents.Content = i.ToString() + " " + pointsQueue.q.First<coordinates>().x.ToString() + " " + pointsQueue.q.First<coordinates>().y.ToString();
                                        }
                                ));
                                pointsQueue.q.Dequeue();
                                Thread.Sleep(1000000000);
                            }
                        }
                    )
                );
            i++;
            t.Start();
        }

        /******************************************* Thread function *******************************************************/

        void kinectSensorChooser1_KinectSensorChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            KinectSensor old = (KinectSensor)e.OldValue;

            StopKinect(old);

            KinectSensor sensor = (KinectSensor)e.NewValue;

            if (sensor == null)
            {
                return;
            }

            


            var parameters = new TransformSmoothParameters
            {
                Smoothing = 0.3f,
                Correction = 0.0f,
                Prediction = 0.0f,
                JitterRadius = 1.0f,
                MaxDeviationRadius = 0.5f
            };
            sensor.SkeletonStream.Enable(parameters);

            sensor.SkeletonStream.Enable();

            sensor.AllFramesReady += new EventHandler<AllFramesReadyEventArgs>(sensor_AllFramesReady);
            sensor.DepthStream.Enable(DepthImageFormat.Resolution640x480Fps30); 
            sensor.ColorStream.Enable(ColorImageFormat.RgbResolution640x480Fps30);

            try
            {
                sensor.Start();
            }
            catch (System.IO.IOException)
            {
                kinectSensorChooser1.AppConflictOccurred();
            }
        }

        void sensor_AllFramesReady(object sender, AllFramesReadyEventArgs e)
        {
            if (closing)
            {
                return;
            }

            //Get a skeleton
            Skeleton first =  GetFirstSkeleton(e);

            if (first == null)
            {
                return; 
            }



            //set scaled position
            //ScalePosition(headImage, first.Joints[JointType.Head]);
            ScalePosition(leftHand, first.Joints[JointType.HandLeft]);
            ScalePosition(leftWrist, first.Joints[JointType.WristLeft]);

            ScalePosition(rightHand, first.Joints[JointType.HandRight]);

            GetCameraPoint(first, e); 

        }

        void ComputeCoordinates()
        {
            float[] rightFeet = playerAttributes.RightLeg;
            float[] leftFeet = playerAttributes.LeftLeg;
            float[] midpoint = new float[3];
            midpoint[0] = (rightFeet[0] + leftFeet[0]) / 2;
            midpoint[1] = (rightFeet[1] + leftFeet[1]) / 2;
            midpoint[2] = (rightFeet[2] + leftFeet[2]) / 2;
            

            float temp = ((midpoint[1] - playerAttributes.RightShoulder[1]) / (playerAttributes.RightHand[1] - playerAttributes.RightShoulder[1]));
            finalpoints[0] = temp * (playerAttributes.RightHand[0] - playerAttributes.RightShoulder[0]) + playerAttributes.RightShoulder[0];
            finalpoints[1] = midpoint[1];
            finalpoints[2] = temp * (playerAttributes.RightHand[2] - playerAttributes.RightShoulder[2]) + playerAttributes.RightShoulder[2];


            gotoX.Content = "gotoX = " + (midpoint[0]-finalpoints[0]).ToString();
            gotoY.Content = "gotoY = " + (midpoint[1] - finalpoints[1]).ToString();
            gotoD.Content = "gotoZ = " + (midpoint[2] - finalpoints[2]).ToString();
            /*
            fromX.Content = midpoint[0];
            fromY.Content = midpoint[1];
            fromD.Content = midpoint[2];
             */

            insertPoints = true;
        }

        void GetCameraPoint(Skeleton first, AllFramesReadyEventArgs e)
        {

            using (DepthImageFrame depth = e.OpenDepthImageFrame())
            {
                if (depth == null ||
                    kinectSensorChooser1.Kinect == null)
                {
                    return;
                }
                

                //Map a joint location to a point on the depth map
                //head
                
                DepthImagePoint headDepthPoint =
                    depth.MapFromSkeletonPoint(first.Joints[JointType.Head].Position);
               
                //left hand
                DepthImagePoint leftDepthPoint =
                    depth.MapFromSkeletonPoint(first.Joints[JointType.HandLeft].Position);
                playerAttributes.LeftHand[0] = leftDepthPoint.X;
                playerAttributes.LeftHand[1] = leftDepthPoint.Y;
                playerAttributes.LeftHand[2] = leftDepthPoint.Depth;

                //wrist left
                DepthImagePoint leftWristDepthPoint =
                    depth.MapFromSkeletonPoint(first.Joints[JointType.WristLeft].Position);
                playerAttributes.LeftWrist[0] = leftWristDepthPoint.X;
                playerAttributes.LeftWrist[1] = leftWristDepthPoint.Y;
                playerAttributes.LeftWrist[2] = leftWristDepthPoint.Depth;
                //elbow left
                DepthImagePoint leftelbowDepthPoint =
                    depth.MapFromSkeletonPoint(first.Joints[JointType.ElbowLeft].Position);
                playerAttributes.LeftElbow[0] = leftelbowDepthPoint.X;
                playerAttributes.LeftElbow[1] = leftelbowDepthPoint.Y;
                playerAttributes.LeftElbow[2] = leftelbowDepthPoint.Depth;
                //shoulder left
                DepthImagePoint leftShoulderDepthPoint =
                    depth.MapFromSkeletonPoint(first.Joints[JointType.ShoulderLeft].Position);
                playerAttributes.LeftShoulder[0] = leftShoulderDepthPoint.X;
                playerAttributes.LeftShoulder[1] = leftShoulderDepthPoint.Y;
                playerAttributes.LeftShoulder[2] = leftShoulderDepthPoint.Depth;

               
                //right hand
                DepthImagePoint rightDepthPoint =
                    depth.MapFromSkeletonPoint(first.Joints[JointType.HandRight].Position);
                playerAttributes.RightHand[0] = rightDepthPoint.X;
                playerAttributes.RightHand[1] = rightDepthPoint.Y;
                playerAttributes.RightHand[2] = rightDepthPoint.Depth;
                    

                //right wrist 
                DepthImagePoint rightWristDepthPoint =
                    depth.MapFromSkeletonPoint(first.Joints[JointType.WristRight].Position);
                playerAttributes.RightWrist[0] = rightWristDepthPoint.X;
                playerAttributes.RightWrist[1] = rightWristDepthPoint.Y;
                playerAttributes.RightWrist[2] = rightWristDepthPoint.Depth;
                //right elbow
                DepthImagePoint rightelbowDepthPoint =
                    depth.MapFromSkeletonPoint(first.Joints[JointType.ElbowRight].Position);
                playerAttributes.RightElbow[0] = rightelbowDepthPoint.X;
                playerAttributes.RightElbow[1] = rightelbowDepthPoint.Y;
                playerAttributes.RightElbow[2] = rightelbowDepthPoint.Depth;
                //right shoulder
                DepthImagePoint rightShoulderDepthPoint =
                    depth.MapFromSkeletonPoint(first.Joints[JointType.ShoulderRight].Position);
                playerAttributes.RightShoulder[0] = rightShoulderDepthPoint.X;
                playerAttributes.RightShoulder[1] = rightShoulderDepthPoint.Y;
                playerAttributes.RightShoulder[2] = rightShoulderDepthPoint.Depth;

                //right leg
                DepthImagePoint rightLegDepthPoint =
                    depth.MapFromSkeletonPoint(first.Joints[JointType.FootRight].Position);
                playerAttributes.RightLeg[0] = rightLegDepthPoint.X;
                playerAttributes.RightLeg[1] = rightLegDepthPoint.Y;
                playerAttributes.RightLeg[2] = rightLegDepthPoint.Depth;

                //left leg
                DepthImagePoint leftLegDepthPoint =
                    depth.MapFromSkeletonPoint(first.Joints[JointType.FootLeft].Position);
                playerAttributes.LeftLeg[0] = leftLegDepthPoint.X;
                playerAttributes.LeftLeg[1] = leftLegDepthPoint.Y;
                playerAttributes.LeftLeg[2] = leftLegDepthPoint.Depth;


                //Compute the 2d Co-ordinates Using joint co-ordinates; 
                


                //Map a depth point to a point on the color image
                //head
                ColorImagePoint headColorPoint =
                    depth.MapToColorImagePoint(headDepthPoint.X, headDepthPoint.Y,
                    ColorImageFormat.RgbResolution640x480Fps30);
                //left hand
                ColorImagePoint leftColorPoint =
                    depth.MapToColorImagePoint(leftDepthPoint.X, leftDepthPoint.Y,
                    ColorImageFormat.RgbResolution640x480Fps30);
                //left Wrist
                ColorImagePoint leftWristColorPoint =
                    depth.MapToColorImagePoint(leftWristDepthPoint.X, leftWristDepthPoint.Y,
                    ColorImageFormat.RgbResolution640x480Fps30);
                //left Elbow
                ColorImagePoint leftElbowColorPoint =
                    depth.MapToColorImagePoint(leftelbowDepthPoint.X, leftelbowDepthPoint.Y,
                    ColorImageFormat.RgbResolution640x480Fps30);
                //left shoulder
                ColorImagePoint leftShoulderColorPoint =
                    depth.MapToColorImagePoint(leftShoulderDepthPoint.X, leftShoulderDepthPoint.Y,
                    ColorImageFormat.RgbResolution640x480Fps30);

                //right hand
                ColorImagePoint rightColorPoint =
                    depth.MapToColorImagePoint(rightDepthPoint.X, rightDepthPoint.Y,
                    ColorImageFormat.RgbResolution640x480Fps30);
                //right Wrist
                ColorImagePoint rightWristColorPoint =
                    depth.MapToColorImagePoint(rightWristDepthPoint.X, rightWristDepthPoint.Y,
                    ColorImageFormat.RgbResolution640x480Fps30);
                //right Elbow
                ColorImagePoint rightElbowColorPoint =
                    depth.MapToColorImagePoint(rightelbowDepthPoint.X, rightelbowDepthPoint.Y,
                    ColorImageFormat.RgbResolution640x480Fps30);
                //right Shoulder
                ColorImagePoint rightShoulderColorPoint =
                    depth.MapToColorImagePoint(rightShoulderDepthPoint.X, rightShoulderDepthPoint.Y,
                    ColorImageFormat.RgbResolution640x480Fps30);



                if (playerAttributes.LeftHand[1] < playerAttributes.LeftShoulder[1])
                {
                    gesturelock.Content = "Gesture is Locked";
                    //Action to be taken
                    ComputeCoordinates();
                }
                else
                {
                    if (insertPoints)
                    {
                        // inserting points into queue
                        coordinates coor = new coordinates();
                        coor.x = finalpoints[0];
                        coor.y = finalpoints[2];
                        pointsQueue.q.Enqueue(coor);
                        qsize.Content = "Queue content is " + pointsQueue.q.First<coordinates>().x.ToString() + " " + pointsQueue.q.First<coordinates>().y.ToString();
                        insertPoints = false;
                        startthread();
                    }
                    gesturelock.Content = "Gesture is Not Locked";
                    /*
                    gotoD.Content = "";
                    gotoX.Content = "";
                    gotoY.Content = "";
                    fromD.Content = "";
                    fromX.Content = "";
                    fromY.Content = "";
                     */
                }


                //Set location
                CameraPosition(Headimage, headColorPoint);
                CameraPosition(leftHand, leftColorPoint);
                CameraPosition(rightHand, rightColorPoint);
                CameraPosition(leftWrist, leftWristColorPoint);
                CameraPosition(leftElbow, leftElbowColorPoint);
                CameraPosition(leftShoulder, leftShoulderColorPoint);
                CameraPosition(rightWrist, rightWristColorPoint);
                CameraPosition(rightElbow, rightElbowColorPoint);
                CameraPosition(rightShoulder, rightShoulderColorPoint);

            }        
        }


        Skeleton GetFirstSkeleton(AllFramesReadyEventArgs e)
        {
            using (SkeletonFrame skeletonFrameData = e.OpenSkeletonFrame())
            {
                if (skeletonFrameData == null)
                {
                    return null; 
                }

                
                skeletonFrameData.CopySkeletonDataTo(allSkeletons);

                //get the first tracked skeleton
                Skeleton first = (from s in allSkeletons
                                         where s.TrackingState == SkeletonTrackingState.Tracked
                                         select s).FirstOrDefault();

                return first;

            }
        }

        private void StopKinect(KinectSensor sensor)
        {
            if (sensor != null)
            {
                if (sensor.IsRunning)
                {
                    //stop sensor 
                    sensor.Stop();

                    //stop audio if not null
                    if (sensor.AudioSource != null)
                    {
                        sensor.AudioSource.Stop();
                    }


                }
            }
        }

        private void CameraPosition(FrameworkElement element, ColorImagePoint point)
        {
            //Divide by 2 for width and height so point is right in the middle 
            // instead of in top/left corner
            Canvas.SetLeft(element, point.X - element.Width / 2);
            Canvas.SetTop(element, point.Y - element.Height / 2);

        }

        private void ScalePosition(FrameworkElement element, Joint joint)
        {
            //convert the value to X/Y
            //Joint scaledJoint = joint.ScaleTo(1280, 720); 
            
            //convert & scale (.3 = means 1/3 of joint distance)
            Joint scaledJoint = joint.ScaleTo(1280, 720, .3f, .3f);

            Canvas.SetLeft(element, scaledJoint.Position.X);
            Canvas.SetTop(element, scaledJoint.Position.Y); 
            
        }


        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            closing = true; 
            StopKinect(kinectSensorChooser1.Kinect); 
        }



    }
}
