﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SkeletalTracking
{
    public struct coordinates{
        public float x;
        public float y;
    }
    public partial class PointsQueue
    {
        private Queue<coordinates> queue = new Queue<coordinates>();

        public Queue<coordinates> q
        {
            get { return queue; }
            set { queue = value; }
        }

    }
}
